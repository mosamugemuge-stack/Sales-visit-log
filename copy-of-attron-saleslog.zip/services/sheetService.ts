import { VisitLog, FormStatus, User } from '../types';

// ==============================================================================
// ⚠️ IMPORTANT: REPLACE THIS URL WITH YOUR DEPLOYED GOOGLE APPS SCRIPT WEB APP URL
// ==============================================================================
const API_URL = 'https://script.google.com/macros/s/AKfycbwN7bHwzX5-WbfjnF3qEk04xTJf8KAi8oMzVxAorpJQzz5klD68ulAPiiVszR0g51Wl/exec';

// Generic API caller
const apiCall = async (action: string, payload: any = {}) => {
  if (API_URL.includes('_PLACEHOLDER_')) {
      console.warn("API URL not set. Falling back to localStorage simulation mode for demo purposes.");
      return mockApiCall(action, payload);
  }

  try {
    // 1. We use POST method.
    // 2. We set Content-Type to 'text/plain;charset=utf-8' to force a "Simple Request".
    //    This prevents the browser from sending a CORS Preflight (OPTIONS) request, 
    //    which Google Apps Script does not support.
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        "Content-Type": "text/plain;charset=utf-8",
      },
      body: JSON.stringify({ action, ...payload }),
    });
    
    if (!response.ok) {
        throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    if (data.status === 'error') {
      throw new Error(data.message);
    }
    
    return data.data || data.user || data; 
  } catch (error: any) {
    console.error("API Call failed:", error);
    
    // Provide a helpful message for the common "Failed to fetch" CORS/Permission error
    if (error.name === 'TypeError' && error.message === 'Failed to fetch') {
        throw new Error("Network request failed. Please ensure:\n1. Your Google Apps Script is deployed as 'Web App'.\n2. 'Who has access' is set to 'Anyone'.\n3. The API_URL in sheetService.ts is correct.");
    }
    
    throw error;
  }
};

export const sheetService = {
  // --- AUTHENTICATION ---
  login: async (email: string, password: string): Promise<User> => {
      const res = await apiCall('login', { email, password });
      return res; // returns User object
  },

  signup: async (name: string, email: string, password: string): Promise<User> => {
      const res = await apiCall('signup', { name, email, password });
      return res;
  },

  // --- USER DATA ---
  getAllUsers: async (): Promise<User[]> => {
    return await apiCall('getUsers');
  },

  updateUserProfile: async (email: string, name: string, password?: string): Promise<User> => {
    const res = await apiCall('updateUser', { email, name, password });
    return res;
  },
  
  updateUserPassword: async (email: string, password: string): Promise<void> => {
    await apiCall('updateUser', { email, password });
  },

  // --- VISITS DATA ---
  getAllVisits: async (): Promise<VisitLog[]> => {
    return await apiCall('getAllVisits');
  },

  getVisitsByUser: async (email: string): Promise<VisitLog[]> => {
    return await apiCall('getVisitsByUser', { email });
  },

  getActiveVisit: async (email: string): Promise<VisitLog | null> => {
    const visits = await apiCall('getVisitsByUser', { email });
    return visits.find((v: VisitLog) => !v.CheckOutTime) || null;
  },

  getPendingVisits: async (email: string): Promise<VisitLog[]> => {
    const visits = await apiCall('getVisitsByUser', { email });
    return visits.filter((v: VisitLog) => v.CheckOutTime && v.FormStatus === 'Pending');
  },

  // --- ACTIONS ---
  checkIn: async (visit: Partial<VisitLog>): Promise<VisitLog> => {
    return await apiCall('checkIn', visit);
  },

  checkOut: async (visitId: string, lat: number, lng: number): Promise<VisitLog> => {
    return await apiCall('checkOut', { visitId, lat, lng });
  },

  updateVisitForm: async (visitId: string, details: Partial<VisitLog>): Promise<void> => {
    await apiCall('updateVisit', { id: visitId, ...details });
  },

  generateSampleData: async (): Promise<void> => {
    await apiCall('generateSampleData');
  },
};


// ------------------------------------------------------------------
// MOCK FALLBACK (Only used if API_URL is not set)
// ------------------------------------------------------------------
const mockApiCall = async (action: string, payload: any) => {
    await new Promise(r => setTimeout(r, 500)); // Simulate latency
    const STORAGE_KEY = 'ATTRON_VISIT_LOGS';
    const USERS_KEY = 'ATTRON_REGISTERED_USERS';
    
    const getVisits = () => JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    const saveVisits = (d: any) => localStorage.setItem(STORAGE_KEY, JSON.stringify(d));
    const getUsers = () => JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const saveUsers = (d: any) => localStorage.setItem(USERS_KEY, JSON.stringify(d));

    // Seed Admin if empty
    if (getUsers().length === 0) {
        saveUsers([{ email: 'admin@admin.com', name: 'Administrator', password: 'admin123', isAdmin: true }]);
    }

    switch(action) {
        case 'login': {
            const user = getUsers().find((u: any) => u.email.toLowerCase() === payload.email.toLowerCase() && u.password === payload.password);
            if (user) return { email: user.email, name: user.name, isAdmin: user.isAdmin };
            throw new Error('Invalid credentials');
        }
        case 'signup': {
            const users = getUsers();
            if (users.find((u: any) => u.email === payload.email)) throw new Error('User exists');
            const newUser = { email: payload.email, name: payload.name, password: payload.password, isAdmin: false };
            saveUsers([...users, newUser]);
            return newUser;
        }
        case 'getUsers': return getUsers();
        case 'updateUser': {
            const users = getUsers();
            const idx = users.findIndex((u: any) => u.email === payload.email);
            if (idx === -1) throw new Error("User not found");
            if (payload.name) users[idx].name = payload.name;
            if (payload.password) users[idx].password = payload.password;
            saveUsers(users);
            return users[idx];
        }
        case 'getAllVisits': return getVisits().sort((a: any, b: any) => new Date(b.CheckInTime).getTime() - new Date(a.CheckInTime).getTime());
        case 'getVisitsByUser': return getVisits().filter((v: any) => v.UserEmail === payload.email).sort((a: any, b: any) => new Date(b.CheckInTime).getTime() - new Date(a.CheckInTime).getTime());
        case 'checkIn': {
            const newV = { 
                id: crypto.randomUUID(), 
                ...payload, 
                CheckInTime: new Date().toISOString(), 
                CheckOutTime: null, 
                FormStatus: 'Pending'
            };
            saveVisits([...getVisits(), newV]);
            return newV;
        }
        case 'checkOut': {
            const visits = getVisits();
            const v = visits.find((v: any) => v.id === payload.visitId);
            if(v) {
                v.CheckOutTime = new Date().toISOString();
                v.CheckOutLat = payload.lat;
                v.CheckOutLong = payload.lng;
                v.FormStatus = 'Pending';
                saveVisits(visits);
                return v;
            }
            throw new Error('Visit not found');
        }
        case 'updateVisit': {
            const visits = getVisits();
            const idx = visits.findIndex((v: any) => v.id === payload.id);
            if (idx !== -1) {
                visits[idx] = { ...visits[idx], ...payload, FormStatus: 'Completed' };
                saveVisits(visits);
                return {};
            }
             throw new Error('Visit not found');
        }
        case 'generateSampleData': return {};
    }
}