import React, { useEffect, useState } from 'react';
import { User, VisitLog } from '../types';
import { sheetService } from '../services/sheetService';
import { Card, StatusBadge } from '../components/UIComponents';
import { RefreshCw, Search, Calendar, User as UserIcon, Clock, MapPin } from 'lucide-react';

interface HistoryProps {
  user: User;
  onOpenVisit: (visit: VisitLog) => void;
}

export const History: React.FC<HistoryProps> = ({ user, onOpenVisit }) => {
  const [visits, setVisits] = useState<VisitLog[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Filters
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const loadVisits = async () => {
    setLoading(true);
    try {
      let data: VisitLog[] = [];
      if (user.isAdmin) {
        data = await sheetService.getAllVisits();
      } else {
        data = await sheetService.getVisitsByUser(user.email);
      }
      setVisits(data);
    } catch (err) {
      console.error("Failed to load history", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVisits();
  }, [user]);

  const filteredVisits = visits.filter(visit => {
    const visitDate = new Date(visit.CheckInTime).setHours(0,0,0,0);
    const start = startDate ? new Date(startDate).setHours(0,0,0,0) : null;
    const end = endDate ? new Date(endDate).setHours(0,0,0,0) : null;

    // Date Range Check
    if (start && visitDate < start) return false;
    if (end && visitDate > end) return false;

    // Search Check (Company Name or User Name if admin)
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      const matchCompany = visit.CompanyName.toLowerCase().includes(term);
      const matchUser = visit.UserEmail.toLowerCase().includes(term);
      return matchCompany || (user.isAdmin && matchUser);
    }

    return true;
  });

  const formatDate = (isoString: string) => {
    return new Date(isoString).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const formatTime = (isoString: string) => {
    return new Date(isoString).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="pb-24 pt-6 max-w-md mx-auto space-y-4">
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-2xl font-bold text-white">History Log</h2>
        <button onClick={loadVisits} disabled={loading} className="text-[#ffd008] hover:text-[#e6bb07] p-2 bg-zinc-900 rounded-full">
           <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Filters */}
      <Card className="bg-zinc-900 p-4 shadow-sm border-zinc-800">
         <div className="grid grid-cols-2 gap-3 mb-3">
            <div>
                <label className="text-[10px] uppercase font-bold text-zinc-500 block mb-1">Start Date</label>
                <input 
                    type="date" 
                    value={startDate} 
                    onChange={e => setStartDate(e.target.value)}
                    className="w-full text-sm p-2 border border-zinc-700 bg-zinc-800 text-white rounded-lg outline-none focus:border-[#ffd008]"
                />
            </div>
            <div>
                <label className="text-[10px] uppercase font-bold text-zinc-500 block mb-1">End Date</label>
                <input 
                    type="date" 
                    value={endDate} 
                    onChange={e => setEndDate(e.target.value)}
                    className="w-full text-sm p-2 border border-zinc-700 bg-zinc-800 text-white rounded-lg outline-none focus:border-[#ffd008]"
                />
            </div>
         </div>
         <div className="relative">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
            <input 
                type="text" 
                placeholder={user.isAdmin ? "Search Company or User Email..." : "Search Company..."}
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-sm border border-zinc-700 bg-zinc-800 text-white rounded-lg outline-none focus:border-[#ffd008]"
            />
         </div>
      </Card>
      
      {/* List */}
      <div className="space-y-3">
        {filteredVisits.length === 0 ? (
           <div className="text-center py-12 text-zinc-500 bg-zinc-900 rounded-xl border border-dashed border-zinc-800">
              {loading ? 'Loading records...' : 'No records found.'}
           </div>
        ) : (
            filteredVisits.map((visit) => (
                <div 
                    key={visit.id} 
                    className={`
                        bg-zinc-900 p-4 rounded-xl border shadow-sm hover:shadow-md transition-all group relative
                        ${visit.FormStatus === 'Pending' ? 'border-l-4 border-l-yellow-600 border-zinc-800' : 'border-l-4 border-l-green-600 border-zinc-800'}
                    `}
                >
                    <div className="flex justify-between items-start mb-2 cursor-pointer" onClick={() => onOpenVisit(visit)}>
                        <div>
                             <h3 className="font-bold text-white text-lg group-hover:text-[#ffd008] transition-colors">{visit.CompanyName}</h3>
                             {user.isAdmin && (
                                 <div className="flex items-center gap-1 text-xs text-zinc-500 mt-1">
                                     <UserIcon className="w-3 h-3" /> {visit.UserEmail}
                                 </div>
                             )}
                        </div>
                        <StatusBadge status={visit.FormStatus} />
                    </div>

                    <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center gap-4 text-xs text-zinc-400 bg-black/20 p-2 rounded-lg flex-1 cursor-pointer hover:bg-black/40" onClick={() => onOpenVisit(visit)}>
                            <div className="flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {formatDate(visit.CheckInTime)}
                            </div>
                            <div className="flex items-center gap-1 font-mono text-zinc-500">
                                <Clock className="w-3 h-3" />
                                {formatTime(visit.CheckInTime)}
                                 - 
                                {visit.CheckOutTime ? formatTime(visit.CheckOutTime) : '...'}
                            </div>
                        </div>

                        {/* Map Button */}
                        <a 
                            href={`https://www.google.com/maps/search/?api=1&query=${visit.CheckInLat},${visit.CheckInLong}`}
                            target="_blank" 
                            rel="noreferrer"
                            className="ml-2 p-2 rounded-full bg-zinc-800 text-zinc-400 hover:bg-[#ffd008] hover:text-black transition-colors"
                            title="View Location"
                        >
                            <MapPin className="w-4 h-4" />
                        </a>
                    </div>
                </div>
            ))
        )}
      </div>

    </div>
  );
};