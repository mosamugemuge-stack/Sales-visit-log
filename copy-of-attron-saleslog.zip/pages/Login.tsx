import React, { useState } from 'react';
import { User } from '../types';
import { sheetService } from '../services/sheetService';
import { Button, Input, Card } from '../components/UIComponents';
import { Zap } from 'lucide-react';

interface LoginProps {
  onLogin: (user: User) => void;
}

type ViewState = 'login' | 'signup' | 'forgot_email' | 'forgot_new_pass';

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [viewState, setViewState] = useState<ViewState>('login');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setIsLoading(true);

    try {
      if (viewState === 'login') {
        const user = await sheetService.login(email, password);
        onLogin(user);
      } else if (viewState === 'signup') {
        const user = await sheetService.signup(name, email, password);
        onLogin(user);
      } else if (viewState === 'forgot_email') {
        setViewState('forgot_new_pass');
        setSuccessMsg("If account exists, enter new password.");
      } else if (viewState === 'forgot_new_pass') {
        if (password !== confirmPassword) {
            throw new Error("Passwords do not match");
        }
        await sheetService.updateUserPassword(email, password);
        setSuccessMsg("Password updated successfully. Please login.");
        setViewState('login');
        setPassword('');
        setConfirmPassword('');
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Operation failed.");
    } finally {
      setIsLoading(false);
    }
  };

  const toggleMode = (mode: ViewState) => {
    setViewState(mode);
    setError(null);
    setSuccessMsg(null);
    setPassword('');
    setConfirmPassword('');
  };

  const getTitle = () => {
      switch(viewState) {
          case 'login': return 'Welcome Back';
          case 'signup': return 'Create Account';
          case 'forgot_email': return 'Reset Password';
          case 'forgot_new_pass': return 'New Password';
      }
  };

  const getButtonText = () => {
      switch(viewState) {
          case 'login': return 'Sign In';
          case 'signup': return 'Create Account';
          case 'forgot_email': return 'Verify Email';
          case 'forgot_new_pass': return 'Update Password';
      }
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4">
      <div className="mb-10 flex flex-col items-center">
        <div className="bg-zinc-900 p-6 rounded-3xl mb-6 shadow-2xl shadow-[#ffd008]/10 relative group border border-zinc-800">
           <img 
              src="https://cdn.prod.website-files.com/6657115058aab72b765211ba/665718e3deabd311909cc367_attrons-logo.webp" 
              alt="Attron" 
              className="h-12 w-auto object-contain"
           />
           <div className="absolute -top-3 -right-3 bg-[#ffd008] text-black text-[10px] px-2 py-0.5 rounded-full font-bold shadow-lg">
             BETA
           </div>
        </div>
        <p className="text-zinc-500 font-medium tracking-wide text-sm">FIELD SALES PORTAL</p>
      </div>

      <Card className="w-full max-w-sm border-t-4 border-t-[#ffd008]">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="text-center mb-6">
            <h2 className="text-xl font-bold text-white">{getTitle()}</h2>
            {successMsg && <p className="text-sm text-green-400 mt-2 font-medium">{successMsg}</p>}
          </div>

          <div className="space-y-4">
            {viewState === 'signup' && (
              <Input 
                label="Full Name"
                placeholder="e.g. John Doe"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            )}
            
            {(viewState !== 'forgot_new_pass') && (
                <Input 
                label="Email Address"
                type="email"
                placeholder="e.g. john@attron.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={viewState === 'forgot_email' && isLoading}
                />
            )}

            {(viewState === 'login' || viewState === 'signup' || viewState === 'forgot_new_pass') && (
              <Input 
                label={viewState === 'forgot_new_pass' ? "New Password" : "Password"}
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            )}

            {viewState === 'forgot_new_pass' && (
              <Input 
                label="Confirm New Password"
                type="password"
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            )}
          </div>

          {error && (
            <div className="text-sm text-red-400 bg-red-900/20 p-3 rounded border border-red-800 text-center">
              {error}
            </div>
          )}

          <div className="pt-2">
            <Button 
              type="submit" 
              fullWidth 
              isLoading={isLoading}
            >
              {getButtonText()}
            </Button>
            
            <div className="mt-6 text-center space-y-3">
              {viewState === 'login' && (
                <>
                    <button
                        type="button"
                        onClick={() => toggleMode('forgot_email')}
                        className="block w-full text-xs text-zinc-500 hover:text-zinc-300 mb-2 transition-colors"
                    >
                        Forgot Password?
                    </button>
                    <button
                        type="button"
                        onClick={() => toggleMode('signup')}
                        className="text-sm text-zinc-400 hover:text-[#ffd008] font-medium transition-colors"
                    >
                        Don't have an account? <span className="underline">Sign Up</span>
                    </button>
                </>
              )}
              {viewState === 'signup' && (
                <button
                    type="button"
                    onClick={() => toggleMode('login')}
                    className="text-sm text-zinc-400 hover:text-[#ffd008] font-medium transition-colors"
                >
                    Already have an account? <span className="underline">Sign In</span>
                </button>
              )}
              {(viewState === 'forgot_email' || viewState === 'forgot_new_pass') && (
                <button
                    type="button"
                    onClick={() => toggleMode('login')}
                    className="text-sm text-zinc-400 hover:text-[#ffd008] font-medium transition-colors"
                >
                    Back to Login
                </button>
              )}
            </div>
          </div>
        </form>
      </Card>
      
      <p className="mt-8 text-xs text-zinc-600">
        © {new Date().getFullYear()} Attron Automotive. Internal use only.
      </p>
    </div>
  );
};