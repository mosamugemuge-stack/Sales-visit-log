import React, { useState } from 'react';
import { User } from '../types';
import { sheetService } from '../services/sheetService';
import { Button, Input, Card } from '../components/UIComponents';
import { LogOut, User as UserIcon, Lock, Shield, Database } from 'lucide-react';

interface AccountProps {
  user: User;
  onLogout: () => void;
  onUserUpdate: (updatedUser: User) => void;
}

export const Account: React.FC<AccountProps> = ({ user, onLogout, onUserUpdate }) => {
  const [name, setName] = useState(user.name);
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<{type: 'success'|'error', text: string} | null>(null);

  const [generating, setGenerating] = useState(false);

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMsg(null);

    try {
        const updated = await sheetService.updateUserProfile(user.email, name, newPassword || undefined);
        onUserUpdate({ ...user, name: updated.name });
        setMsg({ type: 'success', text: 'Profile updated successfully.' });
        setNewPassword('');
    } catch (err: any) {
        setMsg({ type: 'error', text: err.message || 'Failed to update profile.' });
    } finally {
        setLoading(false);
    }
  };

  const handleGenerateData = async () => {
    if(!confirm("This will add sample users and visits to your Sheet. Continue?")) return;
    setGenerating(true);
    setMsg(null);
    try {
        await sheetService.generateSampleData();
        setMsg({ type: 'success', text: 'Sample data generated! Check the Home/History tabs.' });
    } catch (err: any) {
        setMsg({ type: 'error', text: err.message || 'Failed to generate data.' });
    } finally {
        setGenerating(false);
    }
  };

  return (
    <div className="pb-24 pt-6 max-w-md mx-auto space-y-6">
       <div className="text-center">
          <div className="w-20 h-20 bg-[#ffd008] text-black rounded-full flex items-center justify-center text-3xl font-bold mx-auto mb-3 shadow-lg shadow-[#ffd008]/20 ring-4 ring-zinc-900">
             {user.name.charAt(0)}
          </div>
          <h2 className="text-2xl font-bold text-white">{user.name}</h2>
          <p className="text-zinc-500 text-sm">{user.email}</p>
          {user.isAdmin && (
              <span className="inline-flex items-center gap-1 mt-2 px-3 py-1 bg-[#ffd008]/20 text-[#ffd008] text-xs font-bold rounded-full border border-[#ffd008]/30">
                  <Shield className="w-3 h-3" /> Administrator
              </span>
          )}
       </div>

       <Card title="Account Settings" className="border-t-4 border-t-[#ffd008]">
           <form onSubmit={handleUpdate} className="space-y-4">
               <Input 
                  label="Display Name"
                  value={name}
                  onChange={e => setName(e.target.value)}
               />
               
               <div className="pt-2 border-t border-zinc-800">
                    <p className="text-xs text-zinc-500 mb-3 uppercase font-bold tracking-wider">Change Password</p>
                    <Input 
                        label="New Password"
                        type="password"
                        placeholder="Leave blank to keep current"
                        value={newPassword}
                        onChange={e => setNewPassword(e.target.value)}
                    />
               </div>

               {msg && (
                   <p className={`text-sm text-center ${msg.type === 'success' ? 'text-green-400' : 'text-red-400'}`}>
                       {msg.text}
                   </p>
               )}

               <Button 
                type="submit" 
                isLoading={loading} 
                fullWidth 
                variant="secondary"
                disabled={user.isAdmin} 
               >
                   Save Changes
               </Button>
               {user.isAdmin && <p className="text-[10px] text-center text-zinc-600">Admin profile cannot be edited in this demo.</p>}
           </form>
       </Card>

       {user.isAdmin && (
           <Card className="border border-zinc-800 bg-zinc-900">
               <div className="flex items-center gap-2 text-[#ffd008] font-bold text-sm mb-2">
                   <Database className="w-4 h-4" />
                   <span>Developer Tools</span>
               </div>
               <Button 
                    variant="outline" 
                    fullWidth 
                    onClick={handleGenerateData}
                    isLoading={generating}
                    className="border-[#ffd008]/50 text-[#ffd008] hover:bg-[#ffd008] hover:text-black"
                >
                    Generate Sample Data
                </Button>
                <p className="text-[10px] text-center text-zinc-600 mt-2">
                    Injects test users and visit logs into your Sheet.
                </p>
           </Card>
       )}

       <button 
         onClick={onLogout}
         className="w-full flex items-center justify-center gap-2 p-4 text-red-400 bg-red-900/10 hover:bg-red-900/20 rounded-xl font-medium transition-colors border border-red-900/30"
       >
           <LogOut className="w-5 h-5" />
           Sign Out
       </button>
       
       <div className="text-center text-xs text-zinc-700 pt-4">
           Attron SalesLog v1.0.3 Dark
       </div>
    </div>
  );
};