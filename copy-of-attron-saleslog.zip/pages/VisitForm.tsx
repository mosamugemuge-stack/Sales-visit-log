import React, { useState } from 'react';
import { VisitLog } from '../types';
import { sheetService } from '../services/sheetService';
import { Button, Input, TextArea, Card } from '../components/UIComponents';
import { ArrowLeft, CheckCircle2, Save } from 'lucide-react';

interface VisitFormProps {
  visit: VisitLog;
  onBack: () => void;
  onSave: () => void;
}

export const VisitForm: React.FC<VisitFormProps> = ({ visit, onBack, onSave }) => {
  const [formData, setFormData] = useState({
    ContactPerson: visit.ContactPerson || '',
    ContactPhone: visit.ContactPhone || '',
    ContactEmail: visit.ContactEmail || '',
    CustomerProducts: visit.CustomerProducts || '',
    InterestedProducts: visit.InterestedProducts || '',
    MOM: visit.MOM || '',
  });
  const [saving, setSaving] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await sheetService.updateVisitForm(visit.id, formData);
      onSave();
    } catch (error) {
      console.error(error);
      alert("Failed to save report.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-md mx-auto pb-20">
      <div className="flex items-center gap-2 mb-6 cursor-pointer text-zinc-500 hover:text-white" onClick={onBack}>
        <ArrowLeft className="w-5 h-5" />
        <span className="font-medium">Back to Dashboard</span>
      </div>

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">{visit.CompanyName}</h1>
          <p className="text-zinc-500 text-sm">Visit Report</p>
        </div>
        <div className="bg-[#ffd008]/20 p-2 rounded-full">
            <CheckCircle2 className="w-6 h-6 text-[#ffd008]" />
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card title="Contact Information">
          <div className="space-y-4">
            <Input 
              name="ContactPerson"
              label="Contact Person Name"
              placeholder="Who did you meet?"
              value={formData.ContactPerson}
              onChange={handleChange}
              required
            />
            <Input 
              name="ContactPhone"
              label="Phone Number"
              placeholder="+91..."
              value={formData.ContactPhone}
              onChange={handleChange}
            />
            <Input 
              name="ContactEmail"
              label="Email Address"
              type="email"
              placeholder="client@company.com"
              value={formData.ContactEmail}
              onChange={handleChange}
            />
          </div>
        </Card>

        <Card title="Product Discussion">
          <div className="space-y-4">
            <TextArea 
              name="CustomerProducts"
              label="Customer's Current Products"
              placeholder="What do they currently manufacture or sell?"
              value={formData.CustomerProducts}
              onChange={handleChange}
              rows={3}
            />
            <TextArea 
              name="InterestedProducts"
              label="Interested Attron Products"
              placeholder="Which motors or controllers are they interested in?"
              value={formData.InterestedProducts}
              onChange={handleChange}
              rows={3}
            />
          </div>
        </Card>

        <Card title="Meeting Notes">
           <TextArea 
              name="MOM"
              label="Minutes of Meeting (MOM)"
              placeholder="Key takeaways, next steps, action items..."
              value={formData.MOM}
              onChange={handleChange}
              rows={6}
              required
            />
        </Card>

        <div className="fixed bottom-0 left-0 right-0 p-4 bg-zinc-900 border-t border-zinc-800 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] z-10 md:static md:shadow-none md:border-0 md:bg-transparent md:p-0">
          <div className="max-w-md mx-auto">
             <Button type="submit" fullWidth isLoading={saving}>
               <Save className="w-5 h-5 mr-2" />
               Complete & Save Report
             </Button>
          </div>
        </div>
      </form>
    </div>
  );
};