import React, { useEffect, useState, useCallback } from 'react';
import { User, VisitLog } from '../types';
import { sheetService } from '../services/sheetService';
import { getCurrentLocation } from '../services/geoService';
import { Input, Card } from '../components/UIComponents';
import { MapPin, Clock, AlertCircle, RefreshCw, ChevronRight, FileText, ExternalLink } from 'lucide-react';

interface HomeProps {
  user: User;
  onOpenPendingList: () => void;
}

export const Home: React.FC<HomeProps> = ({ user, onOpenPendingList }) => {
  // Common State
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // User State
  const [activeVisit, setActiveVisit] = useState<VisitLog | null>(null);
  const [pendingCount, setPendingCount] = useState(0);
  const [companyName, setCompanyName] = useState('');

  // Admin State
  const [teamStatus, setTeamStatus] = useState<{ user: User, currentVisit: VisitLog | null }[]>([]);

  // Receive activeVisit from App prop if I lifted state, but here I seem to fetch it.
  // The previous user instruction said "Lift state", but the provided file content in prompt still showed fetching here.
  // I will stick to the provided file's logic but ensure it updates correctly. 
  // Actually, to fix the tab switching bug mentioned before, we should assume the parent might pass it or we fetch cleanly.
  // Since I am rewriting the file for styles, I'll keep the fetch logic but ensure it runs on mount.

  const loadData = useCallback(async () => {
    try {
      if (user.isAdmin) {
        // ADMIN: Load all users and their active status
        const [users, allVisits] = await Promise.all([
          sheetService.getAllUsers(),
          sheetService.getAllVisits()
        ]);
        
        const statusMap = users.map(u => {
           const active = allVisits.find(v => v.UserEmail === u.email && !v.CheckOutTime) || null;
           return { user: u, currentVisit: active };
        });
        setTeamStatus(statusMap);

      } else {
        // USER: Load personal status
        const [active, pending] = await Promise.all([
          sheetService.getActiveVisit(user.email),
          sheetService.getPendingVisits(user.email)
        ]);
        setActiveVisit(active);
        setPendingCount(pending.length);
      }
    } catch (err) {
      console.error(err);
      setError("Failed to load dashboard data.");
    }
  }, [user.email, user.isAdmin]);

  useEffect(() => {
    loadData();
    let interval: ReturnType<typeof setInterval>;
    if (user.isAdmin) {
        interval = setInterval(loadData, 30000); // 30s poll
    }
    return () => {
        if(interval) clearInterval(interval);
    }
  }, [loadData, user.isAdmin]);

  const handleToggleCheckInOut = async () => {
    setError(null);
    setLoading(true);
    
    try {
      const location = await getCurrentLocation();

      if (activeVisit) {
        // CHECK OUT
        await sheetService.checkOut(activeVisit.id, location.lat, location.lng);
        setCompanyName(''); 
      } else {
        // CHECK IN
        if (!companyName.trim()) {
          setError("Company Name is required to check in.");
          setLoading(false);
          return;
        }
        await sheetService.checkIn({
          UserEmail: user.email,
          CompanyName: companyName,
          CheckInLat: location.lat,
          CheckInLong: location.lng
        });
      }
      await loadData();
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An error occurred during the process.");
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (isoString: string) => {
    return new Date(isoString).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getDuration = (isoString: string) => {
      const start = new Date(isoString).getTime();
      const now = new Date().getTime();
      const diffMins = Math.floor((now - start) / 60000);
      const hrs = Math.floor(diffMins / 60);
      const mins = diffMins % 60;
      if (hrs > 0) return `${hrs}h ${mins}m`;
      return `${mins}m`;
  };

  // --- ADMIN VIEW ---
  if (user.isAdmin) {
      return (
        <div className="space-y-6 pb-20 pt-6 max-w-lg mx-auto">
            <div className="flex justify-between items-center mb-4">
                <div>
                    <h2 className="text-2xl font-bold text-white">Live Team Status</h2>
                    <p className="text-zinc-500 text-sm">Real-time field force monitoring</p>
                </div>
                <button onClick={() => loadData()} className="p-2 bg-zinc-800 rounded-full hover:bg-zinc-700 text-zinc-400 hover:text-white transition-colors">
                    <RefreshCw className="w-5 h-5" />
                </button>
            </div>

            <div className="grid gap-4">
                {teamStatus.length === 0 && (
                    <p className="text-center text-zinc-600 py-8">No registered users found.</p>
                )}
                {teamStatus.map(({ user: teamUser, currentVisit }) => (
                    <Card key={teamUser.email} className="flex flex-col gap-3 relative overflow-hidden group">
                        {currentVisit && (
                            <div className="absolute top-0 right-0 w-16 h-16 bg-[#ffd008]/20 rounded-bl-full -mr-8 -mt-8"></div>
                        )}
                        
                        <div className="flex justify-between items-start relative z-10">
                            <div className="flex items-center gap-3">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-black ${currentVisit ? 'bg-[#ffd008]' : 'bg-zinc-700 text-white'}`}>
                                    {teamUser.name.charAt(0)}
                                </div>
                                <div>
                                    <h3 className="font-bold text-zinc-100">{teamUser.name}</h3>
                                    <p className="text-xs text-zinc-500">{teamUser.email}</p>
                                </div>
                            </div>
                            
                            <div className={`px-2 py-1 rounded text-xs font-bold uppercase tracking-wide flex items-center gap-1 ${currentVisit ? 'bg-[#ffd008]/20 text-[#ffd008]' : 'bg-zinc-800 text-zinc-600'}`}>
                                {currentVisit ? (
                                    <>
                                        <span className="w-2 h-2 rounded-full bg-[#ffd008] animate-pulse"></span>
                                        ON VISIT
                                    </>
                                ) : (
                                    <>
                                        <span className="w-2 h-2 rounded-full bg-zinc-600"></span>
                                        IDLE
                                    </>
                                )}
                            </div>
                        </div>

                        {currentVisit ? (
                            <div className="bg-black/30 p-3 rounded-lg border border-zinc-800 mt-1">
                                <div className="flex justify-between items-center mb-2">
                                    <span className="font-bold text-white text-sm">{currentVisit.CompanyName}</span>
                                    <span className="text-xs font-mono text-zinc-400">{getDuration(currentVisit.CheckInTime)} elapsed</span>
                                </div>
                                <div className="flex items-center justify-between">
                                     <div className="flex items-center gap-1 text-xs text-zinc-500">
                                        <Clock className="w-3 h-3" />
                                        <span>Started {formatTime(currentVisit.CheckInTime)}</span>
                                     </div>
                                     <a 
                                        href={`https://www.google.com/maps/search/?api=1&query=${currentVisit.CheckInLat},${currentVisit.CheckInLong}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-xs flex items-center gap-1 text-[#ffd008] hover:underline font-medium"
                                     >
                                         <MapPin className="w-3 h-3" />
                                         Locate
                                     </a>
                                </div>
                            </div>
                        ) : (
                            <div className="text-xs text-zinc-600 italic pl-14">
                                Not currently checked in.
                            </div>
                        )}
                    </Card>
                ))}
            </div>
        </div>
      );
  }

  // --- USER VIEW ---
  return (
    <div className="space-y-6 pb-20 max-w-md mx-auto pt-6">
      
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-white">Hello, {user.name.split(' ')[0]}</h2>
        <p className="text-zinc-500">Ready for your visits today?</p>
      </div>

      {/* Error Banner */}
      {error && (
        <div className="bg-red-900/30 text-red-200 p-3 rounded-lg flex items-start gap-2 text-sm border border-red-800/50">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p>{error}</p>
        </div>
      )}

      {/* Check In/Out Card */}
      <Card className="border-t-4 border-t-[#ffd008] shadow-2xl shadow-zinc-900 border-zinc-800 bg-zinc-900">
        <div className="flex flex-col items-center justify-center py-6">
          
          {!activeVisit && (
             <div className="w-full mb-8">
               <label className="block text-xs font-bold text-zinc-500 mb-2 uppercase tracking-wide">Enter Customer Name</label>
               <Input 
                 placeholder="e.g. Tata Motors" 
                 value={companyName}
                 onChange={(e) => setCompanyName(e.target.value)}
                 className="text-lg py-3 shadow-inner"
                 autoFocus
               />
             </div>
          )}

          {activeVisit && (
            <div className="w-full mb-8 bg-[#ffd008]/10 border border-[#ffd008]/30 rounded-xl p-4 text-center shadow-sm">
              <div className="flex items-center justify-center gap-2 mb-2">
                 <div className="w-2 h-2 rounded-full bg-[#ffd008] animate-pulse"></div>
                 <span className="text-xs font-bold text-[#ffd008] uppercase tracking-wider">Checked In</span>
              </div>
              <div className="text-2xl font-bold text-white mb-1">{activeVisit.CompanyName}</div>
              <div className="text-sm text-zinc-400 flex justify-center items-center gap-1">
                <Clock className="w-4 h-4" />
                <span>Since {formatTime(activeVisit.CheckInTime)}</span>
              </div>
            </div>
          )}

          <button
            onClick={handleToggleCheckInOut}
            disabled={loading}
            className={`
              relative w-56 h-56 rounded-full flex flex-col items-center justify-center transition-all duration-300 transform active:scale-95 shadow-xl
              ${activeVisit 
                ? 'bg-zinc-800 hover:bg-zinc-700 ring-4 ring-offset-4 ring-offset-black ring-zinc-800 text-white group' 
                : 'bg-[#ffd008] hover:bg-[#e6bb07] ring-4 ring-offset-4 ring-offset-black ring-[#ffd008] text-black'}
              ${loading ? 'opacity-90 cursor-wait' : ''}
            `}
          >
             {loading ? (
               <RefreshCw className="w-12 h-12 animate-spin" />
             ) : (
               <>
                 {activeVisit ? <LogOutIcon className="w-12 h-12 mb-3 text-red-500" /> : <MapPin className="w-12 h-12 mb-3" />}
                 
                 <span className="text-3xl font-bold tracking-wider">
                   {activeVisit ? 'CHECK OUT' : 'CHECK IN'}
                 </span>
                 <span className={`text-sm mt-2 uppercase font-bold tracking-wide ${activeVisit ? 'text-zinc-500' : 'text-black/60'}`}>
                   {activeVisit ? 'Complete Visit' : 'Start Visit'}
                 </span>
               </>
             )}
          </button>
        </div>
      </Card>

      {/* Pending Forms Button */}
      <button 
        onClick={onOpenPendingList}
        className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-5 shadow-sm hover:shadow-lg hover:border-[#ffd008]/50 transition-all group text-left relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-24 h-24 bg-[#ffd008]/10 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
        <div className="relative z-10 flex items-center justify-between">
            <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#ffd008]/20 flex items-center justify-center text-[#ffd008]">
                    <FileText className="w-6 h-6" />
                </div>
                <div>
                    <h3 className="font-bold text-white text-lg">Pending Reports</h3>
                    <p className="text-zinc-500 text-sm">
                        {pendingCount === 0 
                            ? "No incomplete forms" 
                            : `You have ${pendingCount} forms to fill`}
                    </p>
                </div>
            </div>
            {pendingCount > 0 && (
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-[#ffd008] text-black font-bold text-sm shadow-md">
                    {pendingCount}
                </div>
            )}
            {pendingCount === 0 && (
                 <ChevronRight className="w-5 h-5 text-zinc-700" />
            )}
        </div>
      </button>

    </div>
  );
};

// Simple icon wrapper to use MapPin logic
const LogOutIcon = ({ className }: { className: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
);
