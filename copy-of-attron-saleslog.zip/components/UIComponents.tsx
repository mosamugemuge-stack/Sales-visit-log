import React from 'react';
import { Loader2 } from 'lucide-react';

// --- BUTTON ---
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'outline' | 'ghost';
  isLoading?: boolean;
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  isLoading, 
  fullWidth,
  className = '',
  disabled,
  ...props 
}) => {
  const baseStyles = "inline-flex items-center justify-center px-4 py-3 rounded-lg font-bold transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black disabled:opacity-50 disabled:cursor-not-allowed";
  
  const variants = {
    // Brand Yellow (#ffd008) with Black text
    primary: "bg-[#ffd008] hover:bg-[#e6bb07] text-black focus:ring-[#ffd008] shadow-lg shadow-yellow-900/20",
    secondary: "bg-zinc-800 hover:bg-zinc-700 text-white focus:ring-zinc-600",
    danger: "bg-red-600 hover:bg-red-700 text-white focus:ring-red-500",
    outline: "border-2 border-zinc-700 text-zinc-300 hover:border-[#ffd008] hover:text-[#ffd008] hover:bg-zinc-900",
    ghost: "text-zinc-400 hover:bg-zinc-900 hover:text-white"
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${fullWidth ? 'w-full' : ''} ${className}`}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading && <Loader2 className="w-5 h-5 mr-2 animate-spin" />}
      {children}
    </button>
  );
};

// --- INPUT ---
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input: React.FC<InputProps> = ({ label, error, className = '', ...props }) => {
  return (
    <div className="w-full">
      {label && <label className="block text-sm font-medium text-zinc-400 mb-1">{label}</label>}
      <input 
        className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-[#ffd008] focus:border-[#ffd008] outline-none transition-colors 
        ${error 
            ? 'border-red-500 bg-red-900/10 text-red-100 placeholder-red-300' 
            : 'border-zinc-700 bg-zinc-900 text-white placeholder-zinc-500 hover:border-zinc-600'
        } ${className}`}
        {...props}
      />
      {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
    </div>
  );
};

// --- TEXTAREA ---
interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
}

export const TextArea: React.FC<TextAreaProps> = ({ label, error, className = '', ...props }) => {
  return (
    <div className="w-full">
      {label && <label className="block text-sm font-medium text-zinc-400 mb-1">{label}</label>}
      <textarea 
        className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-[#ffd008] focus:border-[#ffd008] outline-none transition-colors min-h-[100px]
        ${error 
            ? 'border-red-500 bg-red-900/10 text-red-100 placeholder-red-300' 
            : 'border-zinc-700 bg-zinc-900 text-white placeholder-zinc-500 hover:border-zinc-600'
        } ${className}`}
        {...props}
      />
      {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
    </div>
  );
};

// --- CARD ---
export const Card: React.FC<{ children: React.ReactNode; className?: string; title?: string; action?: React.ReactNode }> = ({ 
  children, 
  className = '',
  title,
  action
}) => {
  return (
    <div className={`bg-zinc-900 rounded-xl shadow-lg border border-zinc-800 overflow-hidden ${className}`}>
      {(title || action) && (
        <div className="px-5 py-4 border-b border-zinc-800 flex justify-between items-center bg-zinc-800/50">
          {title && <h3 className="font-semibold text-zinc-100">{title}</h3>}
          {action && <div>{action}</div>}
        </div>
      )}
      <div className="p-5">
        {children}
      </div>
    </div>
  );
};

// --- STATUS BADGE ---
export const StatusBadge: React.FC<{ status: string | null }> = ({ status }) => {
  if (!status) return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-zinc-800 text-zinc-400 border border-zinc-700">In Progress</span>;
  
  const styles = status === 'Completed' 
    ? 'bg-green-900/30 text-green-400 border-green-800'
    : 'bg-yellow-900/30 text-yellow-400 border-yellow-800';

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold border ${styles}`}>
      {status}
    </span>
  );
};