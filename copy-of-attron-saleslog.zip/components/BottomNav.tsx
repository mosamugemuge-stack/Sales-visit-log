import React from 'react';
import { Home, Calendar, User, FileText } from 'lucide-react';

interface BottomNavProps {
  currentTab: 'home' | 'history' | 'account';
  onTabChange: (tab: 'home' | 'history' | 'account') => void;
  pendingCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, onTabChange, pendingCount = 0 }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-zinc-900 border-t border-zinc-800 shadow-[0_-4px_20px_rgba(0,0,0,0.5)] z-40 pb-safe">
      <div className="flex justify-around items-center h-16 max-w-md mx-auto">
        <button 
          onClick={() => onTabChange('home')}
          className={`flex flex-col items-center justify-center w-full h-full transition-all duration-300 ${currentTab === 'home' ? 'text-[#ffd008]' : 'text-zinc-500 hover:text-zinc-300'}`}
        >
          <Home className={`w-6 h-6 mb-1 ${currentTab === 'home' ? 'stroke-[2.5px]' : ''}`} />
          <span className="text-[10px] font-bold uppercase tracking-wide">Home</span>
        </button>

        <button 
          onClick={() => onTabChange('history')}
          className={`flex flex-col items-center justify-center w-full h-full transition-all duration-300 ${currentTab === 'history' ? 'text-[#ffd008]' : 'text-zinc-500 hover:text-zinc-300'}`}
        >
          <div className="relative">
             <Calendar className={`w-6 h-6 mb-1 ${currentTab === 'history' ? 'stroke-[2.5px]' : ''}`} />
          </div>
          <span className="text-[10px] font-bold uppercase tracking-wide">History</span>
        </button>

        <button 
          onClick={() => onTabChange('account')}
          className={`flex flex-col items-center justify-center w-full h-full transition-all duration-300 ${currentTab === 'account' ? 'text-[#ffd008]' : 'text-zinc-500 hover:text-zinc-300'}`}
        >
          <User className={`w-6 h-6 mb-1 ${currentTab === 'account' ? 'stroke-[2.5px]' : ''}`} />
          <span className="text-[10px] font-bold uppercase tracking-wide">Account</span>
        </button>
      </div>
    </div>
  );
};