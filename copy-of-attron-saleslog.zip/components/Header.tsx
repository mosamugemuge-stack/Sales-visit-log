import React from 'react';
import { User } from '../types';
import { LogOut, User as UserIcon, Shield } from 'lucide-react';

interface HeaderProps {
  user: User;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ user, onLogout }) => {
  return (
    <header className="bg-black/80 backdrop-blur-md border-b border-zinc-800 sticky top-0 z-50">
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
            <img 
              src="https://cdn.prod.website-files.com/6657115058aab72b765211ba/665718e3deabd311909cc367_attrons-logo.webp" 
              alt="Attron Automotive" 
              className="h-8 object-contain"
            />
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-end">
            <div className="flex items-center gap-1">
                <span className="text-sm font-semibold text-white leading-none">{user.name}</span>
                {user.isAdmin && <span className="text-[10px] bg-[#ffd008] text-black font-bold px-1 rounded">ADMIN</span>}
            </div>
            <span className="text-xs text-zinc-500 leading-none mt-1">{user.email}</span>
          </div>
          <button 
            onClick={onLogout}
            className="p-2 hover:bg-zinc-800 rounded-full transition-colors text-zinc-400 hover:text-white"
            title="Sign Out"
          >
            <LogOut size={18} />
          </button>
        </div>
      </div>
    </header>
  );
};