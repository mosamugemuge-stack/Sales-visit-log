// ---------------------------------------------------------
// COPY THIS CODE INTO YOUR GOOGLE SHEETS > EXTENSIONS > APPS SCRIPT
// ---------------------------------------------------------

const SCRIPT_PROP = PropertiesService.getScriptProperties();

// Sheet Names
const SHEET_VISITS = 'VisitLogs';
const SHEET_USERS = 'Users';

function setup() {
  const doc = SpreadsheetApp.getActiveSpreadsheet();
  
  // 1. Setup Visits Sheet
  let visitsSheet = doc.getSheetByName(SHEET_VISITS);
  if (!visitsSheet) {
    visitsSheet = doc.insertSheet(SHEET_VISITS);
    visitsSheet.appendRow([
      'id', 'CompanyName', 'UserEmail', 'CheckInTime', 'CheckOutTime', 
      'CheckInLat', 'CheckInLong', 'CheckOutLat', 'CheckOutLong', 
      'FormStatus', 'ContactPerson', 'ContactPhone', 'ContactEmail', 
      'CustomerProducts', 'InterestedProducts', 'MOM'
    ]);
  }

  // 2. Setup Users Sheet
  let usersSheet = doc.getSheetByName(SHEET_USERS);
  if (!usersSheet) {
    usersSheet = doc.insertSheet(SHEET_USERS);
    usersSheet.appendRow(['email', 'name', 'password', 'isAdmin']);
    // Create Default Admin
    usersSheet.appendRow(['admin@admin.com', 'Administrator', 'admin123', true]);
  }
}

function doGet(e) {
  return handleRequest(e);
}

function doPost(e) {
  return handleRequest(e);
}

function handleRequest(e) {
  // CORS / Options check (not strictly needed for "Anyone" access but good practice)
  const lock = LockService.getScriptLock();
  lock.tryLock(10000);

  try {
    let params = {};
    
    // Robust parsing logic
    if (e.postData && e.postData.contents) {
      try {
        params = JSON.parse(e.postData.contents);
      } catch (jsonErr) {
        // Fallback or ignore if not JSON
      }
    }
    
    // Query parameters override body
    if (e.parameter) {
       Object.assign(params, e.parameter);
    }

    const action = params.action;
    
    let result = {};

    if (!action) {
       result = { status: 'error', message: 'No action specified' };
    } else if (action === 'login') {
      result = handleLogin(params);
    } else if (action === 'signup') {
      result = handleSignup(params);
    } else if (action === 'getUsers') {
      result = handleGetUsers();
    } else if (action === 'updateUser') {
      result = handleUpdateUser(params);
    } else if (action === 'getAllVisits') {
      result = handleGetAllVisits();
    } else if (action === 'getVisitsByUser') {
      result = handleGetVisitsByUser(params.email);
    } else if (action === 'checkIn') {
      result = handleCheckIn(params);
    } else if (action === 'checkOut') {
      result = handleCheckOut(params);
    } else if (action === 'updateVisit') {
      result = handleUpdateVisit(params);
    } else if (action === 'generateSampleData') {
      result = handleGenerateSampleData();
    } else {
      result = { status: 'error', message: 'Invalid action: ' + action + '. Please deploy a NEW VERSION of the script.' };
    }

    return ContentService
      .createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}

// --- HANDLERS ---

function handleLogin({ email, password }) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_USERS);
  if (!sheet) return { status: 'error', message: 'Users sheet not found' };
  
  const data = sheet.getDataRange().getValues(); // [Header, Row1, Row2...]
  
  // Normalize email
  email = String(email).toLowerCase();

  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).toLowerCase() === email && String(data[i][2]) === String(password)) {
      return { 
        status: 'success', 
        user: { 
          email: data[i][0], 
          name: data[i][1], 
          isAdmin: data[i][3] === true || data[i][3] === 'true' 
        } 
      };
    }
  }
  return { status: 'error', message: 'Invalid credentials' };
}

function handleSignup({ name, email, password }) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_USERS);
  if (!sheet) return { status: 'error', message: 'Users sheet not found. Run setup.' };

  const data = sheet.getDataRange().getValues();
  
  email = String(email).toLowerCase();
  
  // Check existing
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).toLowerCase() === email) {
      return { status: 'error', message: 'User already exists' };
    }
  }

  sheet.appendRow([email, name, password, false]);
  return { status: 'success', user: { email, name, isAdmin: false } };
}

function handleGetUsers() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_USERS);
  if (!sheet) return { status: 'success', data: [] }; // Return empty if no sheet

  const data = sheet.getDataRange().getValues();
  const users = [];
  // Skip header
  for (let i = 1; i < data.length; i++) {
    users.push({
      email: data[i][0],
      name: data[i][1],
      isAdmin: data[i][3] === true || data[i][3] === 'true'
    });
  }
  return { status: 'success', data: users };
}

function handleUpdateUser({ email, name, password }) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_USERS);
  if (!sheet) return { status: 'error', message: 'Sheet missing' };

  const data = sheet.getDataRange().getValues();
  
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).toLowerCase() === email.toLowerCase()) {
      // Update Name
      if (name) sheet.getRange(i + 1, 2).setValue(name);
      // Update Password
      if (password) sheet.getRange(i + 1, 3).setValue(password);
      
      return { status: 'success', user: { email, name: name || data[i][1] } };
    }
  }
  return { status: 'error', message: 'User not found' };
}

function handleGetAllVisits() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_VISITS);
  if (!sheet) return { status: 'success', data: [] };

  const data = sheet.getDataRange().getValues();
  const visits = _rowsToVisits(data);
  return { status: 'success', data: visits };
}

function handleGetVisitsByUser(email) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_VISITS);
  if (!sheet) return { status: 'success', data: [] };

  const data = sheet.getDataRange().getValues();
  const allVisits = _rowsToVisits(data);
  const userVisits = allVisits.filter(v => v.UserEmail.toLowerCase() === email.toLowerCase());
  return { status: 'success', data: userVisits };
}

function handleCheckIn(params) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_VISITS);
  if (!sheet) return { status: 'error', message: 'VisitLogs sheet missing' };

  const id = Utilities.getUuid();
  const row = [
    id, 
    params.CompanyName, 
    params.UserEmail, 
    new Date().toISOString(), 
    '', // CheckOutTime
    params.CheckInLat, 
    params.CheckInLong, 
    '', // CheckOutLat
    '', // CheckOutLong
    'Pending',
    '', '', '', '', '', '' // Details
  ];
  sheet.appendRow(row);
  return { status: 'success', data: _rowToVisit(row) };
}

function handleCheckOut({ visitId, lat, lng }) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_VISITS);
  if (!sheet) return { status: 'error', message: 'VisitLogs sheet missing' };

  const data = sheet.getDataRange().getValues();
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === visitId) {
      // Update CheckOutTime (Col 5), CheckOutLat (Col 8), CheckOutLong (Col 9), FormStatus (Col 10)
      const rowIdx = i + 1;
      const now = new Date().toISOString();
      
      sheet.getRange(rowIdx, 5).setValue(now);
      sheet.getRange(rowIdx, 8).setValue(lat);
      sheet.getRange(rowIdx, 9).setValue(lng);
      sheet.getRange(rowIdx, 10).setValue('Pending');
      
      // Return updated
      const updatedRow = sheet.getRange(rowIdx, 1, 1, 16).getValues()[0];
      return { status: 'success', data: _rowToVisit(updatedRow) };
    }
  }
  return { status: 'error', message: 'Visit not found' };
}

function handleUpdateVisit(params) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_VISITS);
  if (!sheet) return { status: 'error', message: 'VisitLogs sheet missing' };

  const data = sheet.getDataRange().getValues();
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === params.id) {
      const rowIdx = i + 1;
      
      sheet.getRange(rowIdx, 10).setValue('Completed');
      if(params.ContactPerson) sheet.getRange(rowIdx, 11).setValue(params.ContactPerson);
      if(params.ContactPhone) sheet.getRange(rowIdx, 12).setValue(params.ContactPhone);
      if(params.ContactEmail) sheet.getRange(rowIdx, 13).setValue(params.ContactEmail);
      if(params.CustomerProducts) sheet.getRange(rowIdx, 14).setValue(params.CustomerProducts);
      if(params.InterestedProducts) sheet.getRange(rowIdx, 15).setValue(params.InterestedProducts);
      if(params.MOM) sheet.getRange(rowIdx, 16).setValue(params.MOM);

      return { status: 'success' };
    }
  }
  return { status: 'error', message: 'Visit not found' };
}

function handleGenerateSampleData() {
  const doc = SpreadsheetApp.getActiveSpreadsheet();
  let sheetUsers = doc.getSheetByName(SHEET_USERS);
  let sheetVisits = doc.getSheetByName(SHEET_VISITS);

  // --- SELF HEALING: Create sheets if they don't exist ---
  if (!sheetUsers) {
    sheetUsers = doc.insertSheet(SHEET_USERS);
    sheetUsers.appendRow(['email', 'name', 'password', 'isAdmin']);
    sheetUsers.appendRow(['admin@admin.com', 'Administrator', 'admin123', true]);
  }
  if (!sheetVisits) {
    sheetVisits = doc.insertSheet(SHEET_VISITS);
    sheetVisits.appendRow([
      'id', 'CompanyName', 'UserEmail', 'CheckInTime', 'CheckOutTime', 
      'CheckInLat', 'CheckInLong', 'CheckOutLat', 'CheckOutLong', 
      'FormStatus', 'ContactPerson', 'ContactPhone', 'ContactEmail', 
      'CustomerProducts', 'InterestedProducts', 'MOM'
    ]);
  }
  // --------------------------------------------------------

  // 1. Add Sample Users if they don't exist
  const sampleUsers = [
    ['rahul@attron.com', 'Rahul Sharma', '123456', false],
    ['priya@attron.com', 'Priya Patel', '123456', false]
  ];

  const existingData = sheetUsers.getDataRange().getValues();
  // Safe check if sheet is empty (only header)
  let existingEmails = [];
  if (existingData.length > 1) {
    existingEmails = existingData.map(r => String(r[0]).toLowerCase());
  }

  sampleUsers.forEach(u => {
    if (!existingEmails.includes(u[0])) {
      sheetUsers.appendRow(u);
    }
  });

  // 2. Add Sample Visits
  const baseLat = 18.5204;
  const baseLng = 73.8567;
  
  const visits = [
    // Completed Visit (Yesterday) - Rahul
    [
        Utilities.getUuid(), 
        'Tata Motors', 
        'rahul@attron.com', 
        new Date(Date.now() - 86400000).toISOString(), 
        new Date(Date.now() - 82800000).toISOString(), 
        baseLat + 0.01, baseLng + 0.01, 
        baseLat + 0.01, baseLng + 0.01, 
        'Completed',
        'Mr. Verma', '9876543210', 'verma@tata.com', 
        'Motors, Controllers', 'PMSM Motors', 'Discussed new requirements for EV line.'
    ],
    // Pending Visit (Today Morning) - Rahul
    [
        Utilities.getUuid(), 
        'Mahindra & Mahindra', 
        'rahul@attron.com', 
        new Date(Date.now() - 14400000).toISOString(), 
        new Date(Date.now() - 10800000).toISOString(), 
        baseLat - 0.02, baseLng + 0.02, 
        baseLat - 0.02, baseLng + 0.02, 
        'Pending',
        '', '', '', '', '', '' 
    ],
    // Active Visit (Now) - Priya
    [
        Utilities.getUuid(), 
        'Ola Electric', 
        'priya@attron.com', 
        new Date(Date.now() - 3600000).toISOString(), 
        '', 
        baseLat + 0.05, baseLng - 0.05, 
        '', '', 
        'Pending',
        '', '', '', '', '', '' 
    ]
  ];

  visits.forEach(v => sheetVisits.appendRow(v));

  return { status: 'success', message: 'Sample data generated.' };
}

// --- HELPER ---
function _rowsToVisits(rows) {
  const visits = [];
  // Skip header (row 0)
  for (let i = 1; i < rows.length; i++) {
    visits.push(_rowToVisit(rows[i]));
  }
  // Sort descending by CheckInTime
  return visits.sort((a, b) => new Date(b.CheckInTime) - new Date(a.CheckInTime));
}

function _rowToVisit(row) {
  return {
    id: row[0],
    CompanyName: row[1],
    UserEmail: row[2],
    CheckInTime: row[3],
    CheckOutTime: row[4] || null,
    CheckInLat: row[5],
    CheckInLong: row[6],
    CheckOutLat: row[7] || null,
    CheckOutLong: row[8] || null,
    FormStatus: row[9] || null,
    ContactPerson: row[10] || '',
    ContactPhone: row[11] || '',
    ContactEmail: row[12] || '',
    CustomerProducts: row[13] || '',
    InterestedProducts: row[14] || '',
    MOM: row[15] || ''
  };
}